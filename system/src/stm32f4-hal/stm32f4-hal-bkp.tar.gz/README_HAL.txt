These files are from the original STM stm32cubef4.zip (v1.6.0) 
archive, the folder:

	STM32Cube_FW_F4_V1.6.0/Drivers/STM32F4xx_HAL_Driver/Src


The changes include only adding pragmas to disable compilation warnings.
