The stm32f4*.h and system_stm32f4xx.h files are from stm32cubef4.zip,  
the folder:

	STM32Cube_FW_F4_V1.6.0/Drivers/CMSIS/Device/ST/STM32F4xx/Include

The cmsis_device.h is added for convenience.

